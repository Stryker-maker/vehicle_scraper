Historical CSV archive for vehicle_scraper.

Contains 161 CSV files removed from active data/ paths by PR #39.
Original source commit: e1bd5a532588f55dfe2f88d7f4c069b67bd9444f
Archive generated from PR #39 head: 85dbc4c71cd4b9e8b9c8ced66d7e1ee4ae740ae3
CSV files retain their original data/... paths and original bytes.
Extract this archive at the repository root to restore the historical paths.
MANIFEST.csv records each original Git blob SHA-1, SHA-256, and byte length.
